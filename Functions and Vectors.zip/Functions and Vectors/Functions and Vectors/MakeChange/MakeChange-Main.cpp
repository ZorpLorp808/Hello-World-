// Name Moisees Flores-Ramos
#include <iostream>
#include <vector> 
using namespace std;

void ExactChange(int userTotal, vector<int>& coinVector) {
   const int quarterValue = 25;
   const int dimeValue = 10;
   const int nickelValue = 5;
   const int pennyValue = 1;
   
   // Checks and calculates quarters
   coinVector[3] = userTotal / quarterValue; 
   userTotal %= quarterValue;

   // Checks and calculates dimes
   coinVector[2] = userTotal / dimeValue;
   userTotal %= dimeValue;

   // Checks and calculates nickels
   coinVector[1] = userTotal / nickelValue;
   userTotal %= nickelValue;

   // checks and calculates penniesnbn
   coinVector[0] = userTotal / pennyValue;
}

int main() {
   int totalChange;
   cin >> totalChange; // collect the overaLL chnage the user is trying to calculate

   vector<int> coinVector(4); // Set a vector to 4 since we're only handling 4 types of coins. 

   if (totalChange <= 0) {
      cout << "no change" << endl;
   }
   else {
      ExactChange(totalChange, coinVector); // Function Call to calculate totalChange

      if (coinVector[3] > 0) {
         /* Using the '?' operator evaltuates the expression, if true it evaluates to result1
         in this case it is quarter only if the program detects 1. Otherwise it will print 
         quarters / result2 if more than 1 is detected Same applies for dimes nickels and pennies*/
         cout << coinVector[3] << (coinVector[3] == 1 ? " quarter" : " quarters ") << endl;
      }
      if (coinVector[2] > 0) {
         cout << coinVector[2] << (coinVector[2] == 1 ? " dime " : " dimes ") << endl;
      }
      if (coinVector[1] > 0) {
         cout << coinVector[1] << (coinVector[1] == 1 ? " nickel " : " nickels ") << endl;
      }
      if (coinVector[0] > 0) {
         cout << coinVector[0] << (coinVector[0] == 1 ? " penny " : " pennies ") << endl;
      }
   }
   return 0;
}
