// Name Moises Flores Ramos 
#include <iostream>
#include <vector>
using namespace std;

vector<int> loadVector() {
   vector<int> values(5);
   values[0] = 22;
   values[1] = 54;
   values[2] = 11;
   values[3] = 19;
   values[4] = 3;
   return values;
}

void SortVector(vector<int>& unsortedVector) {
    int n = unsortedVector.size(); // set a int to the vector size so that my code could be more readable and mangeable.
    unsigned int i;
    unsigned int j;

    /* Used a bubble sort algorithm */

    //Outer loop that corresponds to the number of elements to be sorts 
    for (i = 0; i < n - 1; i++) {
        // last element is already in place
        for (j = 0; j < n - 1; ++j) {
            //comparing adjacent elements
            if (unsortedVector[j] > unsortedVector[j + 1]) {
                //swapping if they are in the wrong order
                swap(unsortedVector[j], unsortedVector[j + 1]);
            }
        }
    }
}

void PrintValues(const vector<int>& sortedVector) {
    unsigned int i;

    /*Print updated list*/
    cout << "Sorted Vector\n=============" << endl;
    for (i = 0; i < sortedVector.size(); ++i) {
        cout << sortedVector[i] << endl;
    }
}

int main() {
   vector<int> unsortedVector = loadVector();
    // Print unsorted list 
    cout << "Unsorted Vector\n===============" << endl;
    for (int i = 0; i < unsortedVector.size(); ++i) {
        cout << unsortedVector[i] << endl; 
    }
    //Function call to sort vector 
    SortVector(unsortedVector);
    //fuction call to print updated vector list.
    PrintValues(unsortedVector);
   
    return 0;
}
