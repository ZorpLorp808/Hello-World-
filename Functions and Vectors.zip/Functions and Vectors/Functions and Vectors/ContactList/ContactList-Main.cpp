// Name: Moises Flores Ramos 
// Class: Programming II

#include <iostream>
#include <vector>
#include <string> // wanted to include string library for getline(), push_back(), and pop_back
#include <algorithm> // wanted to incldue algorithm library for find().
using namespace std;

/*Function Prototypes*/
void AddContact(vector<string>& userNames, vector<string>& userNumbers);
void FindContact(const vector<string>& userNames, const vector<string>& userNumbers);

int main() {
    vector<string> names; /* Vector to store contact names */
    vector<string> phoneNumbers; /* Vector to store phone numbers */
    
    int choice;

    do {
        // Display Menu
        cout << "Contact List Menu" << endl;
        cout << "1. Add Contact" << endl;
        cout << "2. Find Contact" << endl;
        cout << "3. Quit" << endl;
        cin >> choice;
        cin.ignore(); /* To ignore leftover newline characters */

        switch (choice) {
            case 1:
            // if user choose option 1, the program is then prompted to run AddContact function.
                AddContact(names, phoneNumbers);
                break;
            case 2: 
            // if user choose option 2, the program is then prompted to run FindContact function.
                FindContact(names, phoneNumbers);
                break;
            case 3:
            // if user chooses option 3, the program quits.
                cout << "Exiting the program. Goodbye!\n";
                break;
            default:
            // if user doesnt provide a value from one of the three options the the default runs
            // and user is asked to try again.
            cout << "Invalid choice. Please try again. \n";
            break;
        }
    } while (choice != 3); /* Loops until the user chooses to quit */
    return 0;
}

void AddContact(vector<string>& userNames, vector<string>& userNumbers) {
    string userName, userNumber;

    // Get contact details like name and phone number
    cout << "Enter contact name: ";
    getline(cin, userName);
    cout << "Enter phone number: ";
    getline(cin, userNumber);

    // Add details to the vector 
    userNames.push_back(userName);
    userNumbers.push_back(userNumber);

    cout << "Contact added successfully!\n";
}

void FindContact(const vector<string>& userNames, const vector<string>& userNumbers) {
    string findName;

    // Get the name to search for 
    cout << "Enter the name to search for: ";
    getline(cin, findName);

    /*Used find() to search for name in vector */
    auto name = find(userNames.begin(), userNames.end(), findName); 

    if (name != userNames.end()) {
        // if found, get the index and display the phone number
        size_t userFound = distance(userNames.begin(), name);
        cout << "Contact found: " << userNames[userFound] << " - " << userNumbers[userFound] << "\n";
    }
    else {
        // if not found, display an error message
        cout << "Contact not found. \n";
    }
}