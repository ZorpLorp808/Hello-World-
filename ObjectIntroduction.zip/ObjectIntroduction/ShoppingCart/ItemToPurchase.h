// Name; Moises Flores-Ramos 
#ifndef ITEM_TO_PURCHASE_H
#define ITEM_TO_PURCHASE_H
#include <string>
using namespace std;

// Class Declaration
class Cart {
    private:
        string itemName = "none";
        int itemPrice = 0;
        int itemQuantity = 0;
    public:
        void SetName(string userItem);
        string GetName() const;
        void SetPrice(int userPrice);
        int GetPrice() const;
        void SetQuantity(int userQuantity);
        int GetQuantity() const;
};
#endif
