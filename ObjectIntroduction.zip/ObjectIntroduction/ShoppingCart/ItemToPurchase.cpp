// Name: Moises Flores-Ramos
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
#include "ItemToPurchase.h"

/*Class Defintions*/
void Cart::SetName(string userItem) {
    itemName = userItem;
}

string Cart::GetName() const {
    return itemName;
}

void Cart::SetPrice(int userPrice) {
    itemPrice = userPrice;
}

int Cart::GetPrice() const {
    return itemPrice;
}

void Cart::SetQuantity(int userQuantity) {
    itemQuantity = userQuantity;
}

int Cart::GetQuantity() const {
    return itemQuantity;
}
