/*Name: Moises Flores-Ramos */
#include <iostream>
using namespace std;

#include "ItemToPurchase.h"

int main() {
   Cart item1;
   Cart item2;
   string userItem;
   int userPrice;
   int userQuantity;

   /*Using getline() since we have to take into account whitespace within string userItem for both item1 and item2*/
   cout << "Item 1" << endl;
   cout << "Enter the item name:" << endl;
   getline(cin, userItem);
   item1.SetName(userItem);

   cout << "Enter the item price:" << endl;
   cin >> userPrice;
   item1.SetPrice(userPrice);

   cout << "Enter the item quantity:" << endl;
   cin >> userQuantity;
   item1.SetQuantity(userQuantity);

   cin.ignore(); /*To allow usere to input a new string after setting item1*/

   cout << "Item 2" << endl;
   cout << "Enter the item name:" << endl;
   getline(cin, userItem);
   item2.SetName(userItem);

   cout << "Enter the item price:" << endl;
   cin >> userPrice;
   item2.SetPrice(userPrice);

   cout << "Enter the item quantity:" << endl;
   cin >> userQuantity;
   item2.SetQuantity(userQuantity);

   /* Calculate the toal cost of each item and both items together*/
   cout << endl << "TOTAL COST" << endl;
   cout << item1.GetName() << " " << item1.GetQuantity() << " @ $" << item1.GetPrice()
      << " = $" << (item1.GetPrice() * item1.GetQuantity()) << endl;
   cout << item2.GetName() << " " << item2.GetQuantity() << " @ $" << item2.GetPrice()
      << " = $" << (item2.GetPrice() * item2.GetQuantity()) << endl;

   int totalCost = (item1.GetPrice() * item1.GetQuantity()) + (item2.GetPrice() * item2.GetQuantity());
   /*Print the totalCost*/
   cout << endl << "Total: $" << totalCost << endl;
   
   return 0;
}
