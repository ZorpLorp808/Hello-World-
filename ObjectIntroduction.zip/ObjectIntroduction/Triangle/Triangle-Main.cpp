/*Name: Mosies Flores-Ramos */

#include <iostream>
#include "Triangle.h"
using namespace std;

int main() {
   Triangle triangle1;
   Triangle triangle2;
   float base, height;
   // TODO: Prompt the user for, read in and set base and height for triangle1 (use SetBase() and SetHeight())
   cin >> base >> height;
   triangle1.SetBase(base);
   triangle1.SetHeight(height);
   // TODO: Prompt the user for, read in and set base and height for triangle2 (use SetBase() and SetHeight())
   cin >> base >>height;
   triangle2.SetBase(base);
   triangle2.SetHeight(height);

   cout << "Triangle with smaller area:";
   // TODO: Determine smaller triangle (use GetArea()) 
   //       and output smaller triangle's info using its PrintInfo()
   if (triangle1.GetArea() < triangle2.GetArea()) { /* an If statement to determine which of the traingles is smaller*/
      cout << " Triangle 1" << endl;
      triangle1.PrintInfo();
   }
   else {
      cout << " Triangle 2" << endl;
      triangle2.PrintInfo();
   }
   return 0;
}