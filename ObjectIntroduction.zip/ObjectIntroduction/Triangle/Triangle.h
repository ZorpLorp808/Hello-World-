// Name: Moises Flores-Ramos 
#ifndef TRIANGLEH
#define TRIANGLEH

// Class Declaration
class Triangle {
   private:
      double base;
      double height;
   
   public:
      void SetBase(double userBase);
      void SetHeight(double userHeight);
      double GetArea() const;
      void PrintInfo() const;
};

#endif